package com.edi.app.service;

import com.edi.app.entity.Usuario;

public interface UserService extends  GenericService<Usuario, Integer>{


}
